from .torch_decorate import main
main.fuzz_plugging()
