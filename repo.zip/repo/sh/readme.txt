Here are the sh. to run 9 different models. But you should link to the HPC of University of Luxembourg first. On your computer, you can run by yourself.


After you successfully run FuMi, you can get a json file (e.g., lstm.json).
Here is the explaination of the results:

  "torch.nn.functional.log_softmax": [    #the name of operator
    22338,                                #the number of calls
    0,                                    #the number of substandard calls
    -3.0481203793897294e-05               #(Ignore the "-")the lower bound on the relative error calculated from Eq. (7). In this case, it is 3.0481203793897294e-05
  ],