This folder is the case study of Conv2d. The pt files here is the original input, original output and fuzzed output catched by FuMi.
To show FuMi's result, run test.py.

For Predoo, the code and data are in ./Predoo